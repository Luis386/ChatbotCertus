import tkinter as tk

from tkinter import scrolledtext, messagebox
from tkinter import PhotoImage
from PIL import Image, ImageTk
import pymysql
from mysql.connector import Error
from datetime import datetime



connection = pymysql.connect(host="localhost",
                                user="root",
                                password="1234",
                                database="DB_CERTUS")

class LoginApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Chat Certus")
        self.master.geometry("600x600")
        bg_image = Image.open("utils/img/fondo-azul.jpeg")
        bg_image = bg_image.resize((1500, 1500))
        self.bg_photo = ImageTk.PhotoImage(bg_image)  # Color de fondo
        self.bg_label = tk.Label(master,image=self.bg_photo)
        self.bg_label.place(relwidth=1 ,  relheight=1)
 

        image_certus= Image.open("utils/img/logo-certus-compartir.jpg")
        

        image_certus = image_certus.resize((250, 200)) 
        
        self.logo_certus = ImageTk.PhotoImage(image_certus)
        
        self.logo_certus_label= tk.Label(master, image=self.logo_certus)
        self.logo_certus_label.pack(pady=20)
    
        image_barras = Image.open("utils/img/Login-Icon.jpeg")
        
        # Cambia el tamaño de la imagen
        image_barras = image_barras.resize((250, 200))  
        
      
        self.logo_barras = ImageTk.PhotoImage(image_barras)
        
        self.logo_barras_label= tk.Label(master, image=self.logo_barras)
        self.logo_barras_label.pack(pady=20)
        self.logo_barras_label.place(x=-30, y=400)
        
        # Username
        self.username_label = tk.Label(master, text="Usuario:")
        self.username_label.pack(pady=10)
        
        self.username_entry = tk.Entry(master)
        self.username_entry.pack(pady=10)
        
        # Password
        self.password_label = tk.Label(master, text="Contraseña:")
        self.password_label.pack(pady=10)
        
        self.password_entry = tk.Entry(master, show="*")
        self.password_entry.pack(pady=10)

        # Login Button
        self.login_button = tk.Button(master, text="Ingresar", command=self.check_credentials)
        self.login_button.pack(pady=10)

        
    def open_chat_window(self):
                chat_root = tk.Tk()
                chat_app = ChatApp(chat_root)
                chat_root.mainloop()

    def check_credentials(self):
     username = self.username_entry.get()
     password = self.password_entry.get()
     try:
            # Establece la conexión a la base de datos
            cursor = connection.cursor()

            # Consulta SQL para verificar las credenciales
            insert_query = "INSERT INTO REGISTRO (username, password) VALUES (%s, %s)"
            cursor.execute(insert_query, (username, password))
            connection.commit()

            self.master.destroy()  
            self.open_chat_window()


     except pymysql.Error as e:
        # Manejar errores
        messagebox.showerror("Error", f"Este usuario ya fue registrado: {str(e)}")

# ... El código del ChatApp iría aquí ...

class ChatApp:
    def __init__(self, master):
        self.master = master
        self.master.title("ChatBot Window")
        
        # Fondo de Gabriel

        bg_image = Image.open("utils/img/Bot-Fondo.jpg")
        self.bg_photo = ImageTk.PhotoImage(bg_image)

        self.bg_label = tk.Label(master, image=self.bg_photo)
        self.bg_label.place(relwidth=1, relheight=1)

        # Configura el cuadro de texto para mostrar la conversación
        self.conversation = scrolledtext.ScrolledText(master, wrap=tk.WORD)
        self.conversation.pack(pady=10, padx=10)


        # Configura el cuadro de entrada para escribir mensajes
        self.entry_text = tk.StringVar()
        self.entry = tk.Entry(master, textvariable=self.entry_text, width=50)
        self.entry.pack(pady=20, padx=20)
        
        self.send_button = tk.Button(master, text="Enviar", command=self.get_response)
        self.send_button.pack(pady=5)
        self.send_button.place(x=530, y=425, width=100, height=30)

        self.entry.bind("<Return>", self.get_response)

        # Diccionario de respuestas
        self.responses = {}

        # Consulta SQL para obtener todas las filas de la tabla
        cursor = connection.cursor()
        query = "SELECT palabra_clave, respuesta FROM tb_respuestas"
        cursor.execute(query)

        # Genera el código
        for row in cursor:
            self.responses[row[0]] = row[1]

        # Asignar el diccionario de respuestas al atributo `responses`
        self.responses = self.responses

def get_response(self, event=None):
    user_input = self.entry_text.get()
    if user_input in self.responses:
        response = self.responses[user_input]
    else:
        response = "No entendí lo que me dijiste."

    self.conversation.insert(tk.END, "\nTu> " + user_input + "\nChatBot Certus> " + response)
    self.conversation.see(tk.END)
    self.entry_text.set("")



if __name__ == "__main__":
    root = tk.Tk()
    login_app = LoginApp(root)
    root.mainloop()


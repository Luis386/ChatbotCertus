package main
import (
    "fmt"
)
type Block struct {
    index int
    hash string
    message string
}
type Blockchain struct {
    blocks []Block
}
func main() {
    blockchain := Blockchain{}
    block1 := Block{index: 1, hash: "Hola mundo", message: "Hola mundo"}
    block2 := Block{index: 2, hash: "¡Adiós!", message: "¡Adiós!"}
    blockchain.blocks = append(blockchain.blocks, block1)
    blockchain.blocks = append(blockchain.blocks, block2)
    for _, block := range blockchain.blocks {
        fmt.Println(block)
    }
}
import hashlib
import time

class Block:
    def __init__(self, index, data, previous_hash):
        self.index = index
        self.data = data
        self.previous_hash = previous_hash
        self.timestamp = time.time()

    def hash(self):
        return hashlib.sha256(
            str(self.index).encode() +
            self.data.encode() +
            self.previous_hash.encode() +
            str(self.timestamp).encode()
        ).hexdigest()

def new_block(data, previous_hash):
    return Block(len(blocks) + 1, data, previous_hash)

def add_block(block):
    blocks.append(block)

def print_blockchain():
    for block in blocks:
        if block.index == 1:
            print("Este es el primer bloque Genesis")
        else:
            print("El segundo es el bloque de la cadena de bloques que como hash del bloque Génesis")
        print(block)

if __name__ == "__main__":
    blocks = []

    block = new_block("Genesis block", "")
    add_block(block)

    block = new_block("Second block", block.hash)
    add_block(block)

    print_blockchain()

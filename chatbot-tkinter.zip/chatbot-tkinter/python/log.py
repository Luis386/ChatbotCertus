import tkinter as tk

from tkinter import scrolledtext, messagebox
from tkinter import PhotoImage
from tkinter import ttk
from PIL import Image, ImageTk
import pymysql
from mysql.connector import Error
from datetime import datetime
import os


connection = pymysql.connect(host="127.0.0.1",
                            user="root",
                            password="1234",
                            database="Chatbot")

class LoginApp:

    def __init__(self, master):
        self.master = master
        self.master.title("TEKI")
        self.master.geometry("600x600")

        bg_image = Image.open("utils/img/fondo-azul.jpeg")
        bg_image = bg_image.resize((600, 600))
        self.bg_photo = ImageTk.PhotoImage(bg_image)
        self.bg_label = tk.Label(master, image=self.bg_photo)
        self.bg_label.place(relwidth=1, relheight=1)
        
        logo_certus = Image.open("utils/img/logo-certus-compartir.jpg")
        logo_certus = logo_certus.resize((150, 100))
        self.logo_certus = ImageTk.PhotoImage(logo_certus)
        self.logo_certus_label = tk.Label(master, image=self.logo_certus)
        self.logo_certus_label.place(x=10, y=10)

        logo_barras = Image.open("utils/img/Login-Icon.jpeg")
        logo_barras = logo_barras.resize((200, 150))
        self.logo_barras = ImageTk.PhotoImage(logo_barras)
        self.logo_barras_label = tk.Label(master, image=self.logo_barras)
        self.logo_barras_label.place(x=450, y=400)

        
        title_color = "#000000"  
        title = tk.Label(master, text="TEKI", font=("Arial", 24), fg=title_color)
        title.config(bg="#E6E6FA")  
        title.place(x=250, y=50)

        self.username_label = tk.Label(master, text="Usuario:", font=("Arial", 15), bg="white", fg="black")
        self.username_label.place(x=130, y=150)  
        self.username_entry = tk.Entry(master, font=("Arial", 12), bg="white", width=20) 
        self.username_entry.place(x=300, y=150)

        self.password_label = tk.Label(master, text="Contraseña:", font=("Arial", 15), bg="white", fg="black")
        self.password_label.place(x=130, y=210)  
        self.password_entry = tk.Entry(master, show="*", font=("Arial", 12), bg="white", width=20)   
        self.password_entry.place(x=300, y=210)

        self.login_button = tk.Button(master, text="Ingresar", font=("Arial", 12), command=self.check_credentials, bg="green", fg="black")
        self.login_button.place(x=200, y=310)

        self.register_button = tk.Button(master, text="Registrarse", font=("Arial", 12), command=self.register, bg="yellow", fg="black")
        self.register_button.place(x=300, y=310)
        
    
    def open_chat_window(self):
                chat_root = tk.Tk()
                chat_app = ChatApp(chat_root)
                chat_root.mainloop()

    def register(self):
        register_window = tk.Toplevel(self.master)
        register_window.title("Registro de Usuario")
        register_window.geometry("600x500")

        register_window.configure(background="#9CDCFF")  

        register_window.wm_geometry("600x500-0+10")  

        additional_text = "Completa el formulario de registro"
        additional_label = tk.Label(register_window, text=additional_text, font=("Helvetica", 20), fg="red")
        additional_label.pack(pady=20)

        style = ttk.Style()
        style.configure("TEntry", padding=5, relief="solid", borderwidth=1, bordercolor="red", foreground="blue", background="blue", font=("Helvetica", 15))

        register_username_label = tk.Label(register_window, text="Usuario:", font=("Helvetica", 15))
        register_username_label.pack(fill=tk.X, padx=150, pady=5)

        register_username_entry = ttk.Entry(register_window, width=30, style="TEntry")
        register_username_entry.pack(pady=5)

        register_password_label = tk.Label(register_window, text="Contraseña:", font=("Helvetica", 15))
        register_password_label.pack(pady=5)

        register_password_entry = ttk.Entry(register_window, width=30, show="*", style="TEntry")
        register_password_entry.pack(pady=5)

        name_label = tk.Label(register_window, text="Nombre:", font=("Helvetica", 15))
        name_label.pack(pady=5)

        name_entry = ttk.Entry(register_window, width=30, style="TEntry")
        name_entry.pack(pady=5, padx=10)

        email_label = tk.Label(register_window, text="Correo Electrónico:", font=("Helvetica", 15))
        email_label.pack(pady=5)

        email_entry = ttk.Entry(register_window, width=30, style="TEntry")
        email_entry.pack(pady=5)

        register_button = tk.Button(register_window, text="Registrarse", command=lambda: self.perform_registration(
            register_username_entry, register_password_entry, name_entry, email_entry) , bg="yellow")
        register_button.pack(pady=30)

         
    def perform_registration(self, username_entry, password_entry, name_entry, email_entry):
        username = username_entry.get()
        password = password_entry.get()
        name = name_entry.get()
        email = email_entry.get()

        try:
            cursor = connection.cursor()

            select_query = "SELECT * FROM REGISTRO WHERE username = %s"
            cursor.execute(select_query, (username,))

            result = cursor.fetchone()

            if result:
                messagebox.showerror("Error de registro", "El usuario ya existe")
            else:
                insert_query = "INSERT INTO REGISTRO (username, password, name, email) VALUES (%s, %s, %s, %s)"
                cursor.execute(insert_query, (username, password, name, email))
                connection.commit()
                messagebox.showinfo("Registro exitoso", "El usuario se ha registrado correctamente")

        except Exception as e:
            messagebox.showerror("Error de registro", f"Ocurrió un error al registrar el usuario: {str(e)}")

    def check_credentials(self):
     username = self.username_entry.get()
     password = self.password_entry.get()
     try:
            cursor = connection.cursor()

            select_query = "SELECT * FROM REGISTRO WHERE username = %s AND password = %s"
            cursor.execute(select_query, (username, password))
            result = cursor.fetchone()


            if result:
                self.master.destroy()
                self.open_chat_window()
            else:
                messagebox.showerror("Error de inicio de sesión", "Usuario o contraseña incorrectos")
     

     except pymysql.Error as e:
        messagebox.showerror("Error", f"Este usuario ya fue registrado: {str(e)}")

class ChatApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Chatbot TEKI")

        bg_image = Image.open("utils/img/Bot-Fondo.jpg")
        self.bg_photo = ImageTk.PhotoImage(bg_image)
        self.bg_label = tk.Label(master, image=self.bg_photo)
        self.bg_label.place(relwidth=1, relheight=1)
        self.conversation = scrolledtext.ScrolledText(master, wrap=tk.WORD)
        self.conversation.pack(pady=10, padx=10)
        container = tk.Frame(self.conversation)
        image = Image.open("utils/img/bot.png")
        photo = ImageTk.PhotoImage(image)
        image_label = tk.Label(container, image=photo)
        image_label.image = photo
        image_label.pack(side=tk.LEFT, anchor="n")

        text_label = tk.Label(container, text="Bienvenido, yo seré tu asistente virtual mejor conocido como TEKI \n. ¿En qué puedo ayudarte?")
        text_label.pack(side=tk.LEFT)
        
        self.conversation.window_create(tk.END, window=container)
        self.conversation.insert(tk.END, "\n")

        self.entry_text = tk.StringVar()
        self.entry = tk.Entry(master, textvariable=self.entry_text, width=50)
        self.entry.pack(pady=30, padx=30, side=tk.LEFT)  
        
        self.send_button = tk.Button(master, text="Enviar", command=self.get_response)
        self.send_button.pack(pady=5)
        self.send_button.place(x=390, y=425, width=100, height=30)  

        self.entry.bind("<Return>", self.get_response)

        self.button = tk.Button(master, text="Cerrar sesión", command=self.logout)
        self.button.place(x=500, y=425, width=100, height=30)  


        self.responses = {}
    def logout(self):
            self.master.destroy() 

    def get_response(self, event=None):
        user_input = self.entry_text.get()
        response = self.respond_to(user_input)

        consulta = user_input
        tiempo_consulta = datetime.now()
        self.save_consulta(consulta, tiempo_consulta)



        self.conversation.insert(tk.END, "\nTu> " + user_input + "\nChatBot Certus> " + response)
        self.conversation.see(tk.END)
        self.entry_text.set("")
    

    def save_consulta(self, consulta, tiempo_consulta):
        try:
            cursor = connection.cursor()
            insert_query = "INSERT INTO mensajes (consulta, tiempo_consulta) VALUES (%s, %s)"
            cursor.execute(insert_query, (consulta, tiempo_consulta))
            connection.commit()
        except pymysql.Error as e:
            print(f"Error al guardar la consulta: {str(e)}")


    def show_consultas():
        try:
            cursor = connection.cursor()
            select_query = "SELECT * FROM mensajes"
            cursor.execute(select_query)
            results = cursor.fetchall()
            for result in results:
                print(f"Consulta: {result[1]}")
                print(f"Tiempo de consulta: {result[2]}")
        except pymysql.Error as e:
            print(f"Error al mostrar las consultas: {str(e)}")


    def get_response_from_database(self, msg):
        try:
            cursor = connection.cursor()
            cursor.execute("SELECT respuesta FROM RESPUESTAS WHERE %s LIKE CONCAT('%%', palabra_clave, '%%')", (msg,))
            respuesta = cursor.fetchone()
            return respuesta[0] if respuesta else "No entiendo lo que quieres decir."
        except pymysql.Error as e:
            messagebox.showerror("Error de consulta", f"Error al consultar la base de datos: {str(e)}")
            return "Error en la consulta"
        finally:
            cursor.close()

        
    def respond_to(self, msg):
        matched_keywords = [keyword for keyword in self.responses.keys() if keyword in msg.lower()]

        responses = []
        for keyword in matched_keywords:
            responses.append(self.responses[keyword])

        if responses:
            response = "\n".join(responses)
        else:
            response = self.get_response_from_database(msg)

        return response
    

if __name__ == "__main__":
    root = tk.Tk()
    login_app = LoginApp(root)
    root.mainloop()

    
let data = { id : 1, animal : "dog" , ...person, country};
console.log(data);